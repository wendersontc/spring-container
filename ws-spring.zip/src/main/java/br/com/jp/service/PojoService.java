package br.com.jp.service;

import br.com.jp.domain.Pojo;

/**
 * @author JP on 10/10/17.
 */
public interface PojoService extends GenericService<Pojo, Long> {
}
