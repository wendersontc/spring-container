insert into pojo(id, nome, sobrenome, numero_rg) values (1, 'Test', 'test', '1')
insert into pojo(id, nome, sobrenome, numero_rg) values (2, 'Test 2', 'test 3', '2')
insert into pojo(id, nome, sobrenome, numero_rg) values (3, 'Test 3', 'test 3', '3')